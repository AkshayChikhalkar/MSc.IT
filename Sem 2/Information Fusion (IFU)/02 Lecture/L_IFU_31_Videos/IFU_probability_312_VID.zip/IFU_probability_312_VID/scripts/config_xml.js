var TSC = TSC || {};

TSC.embedded_config_xml = '<x:xmpmeta tsc:version="2.0.1" xmlns:x="adobe:ns:meta/" xmlns:tsc="http://www.techsmith.com/xmp/tsc/">\
   <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/" xmlns:xmpG="http://ns.adobe.com/xap/1.0/g/" xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:tscDM="http://www.techsmith.com/xmp/tscDM/" xmlns:tscIQ="http://www.techsmith.com/xmp/tscIQ/" xmlns:tscHS="http://www.techsmith.com/xmp/tscHS/" xmlns:stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#" xmlns:stFnt="http://ns.adobe.com/xap/1.0/sType/Font#" xmlns:exif="http://ns.adobe.com/exif/1.0" xmlns:dc="http://purl.org/dc/elements/1.1/">\
      <rdf:Description dc:date="2020-04-08 02:57:11 " dc:source="Camtasia,19.0.10,deu" dc:title="IFU_probability_312_VID" tscDM:firstFrame="IFU_probability_312_VID_First_Frame.png" tscDM:originId="EE6598CE-EE7F-4C01-B309-2033C57177FC" tscDM:project="IFU_probability_312_VID">\
         <xmpDM:duration xmpDM:scale="1/1000" xmpDM:value="460000"/>\
         <xmpDM:videoFrameSize stDim:unit="pixel" stDim:h="720" stDim:w="1280"/>\
         <tsc:langName>\
            <rdf:Bag>\
               <rdf:li xml:lang="de-DE">German</rdf:li></rdf:Bag>\
         </tsc:langName>\
         <xmpDM:Tracks>\
            <rdf:Bag>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="ScreenText" xmpDM:frameRate="f1000" xmpDM:trackName="Screen Text">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:name="Only valid with verbal explanations Prof." xmpDM:startTime="6033" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Dr.-Ing." xmpDM:startTime="6033" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Volker Lohweg 3.1" xmpDM:startTime="6033" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Probability Theory – A priori Probability Example 3.1-1" xmpDM:startTime="6033" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="“Toss a dice” Simple Event: “toss a 1” P[A1] = 1 Desired / 6 Possible = 1/6 Compound Event: “toss" xmpDM:startTime="6033" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="3 or 6” P[A3 U A6] = 2 Desired / 6 Possible = 1/3 Probability of not tossing a 1" xmpDM:startTime="6033" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="P[A1c] = 1 – P[A1] =1 – 1/6 = 5/6 Probability of not tossing 3 or 6 P[(A3 U A6)c]" xmpDM:startTime="6033" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="= 1 – P[A3 U A6] = 1 – 1/3 = 2/3 Die Sample Space (All Possible Events) A1 A2" xmpDM:startTime="6033" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="A3 A4 A5 A6 Simple Compound MPj04026150000[1]" xmpDM:startTime="6033" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Only valid with verbal explanations Prof." xmpDM:startTime="169733" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Dr.-Ing." xmpDM:startTime="169733" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Volker Lohweg 3.1" xmpDM:startTime="169733" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Probability Theory – A priori Probability Example 3.1-1" xmpDM:startTime="169733" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="– Union of Events, cont’d Probability for Union of Events (One trial) For two events: P [toss an even number" xmpDM:startTime="169733" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="or one no." xmpDM:startTime="169733" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="divisible by 3]" xmpDM:startTime="169733" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Only valid with verbal explanations Prof." xmpDM:startTime="312000" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Dr.-Ing." xmpDM:startTime="312000" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Volker Lohweg 3.1" xmpDM:startTime="312000" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Probability Theory – A priori Probability Example 3.1-1" xmpDM:startTime="312000" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="– Compound Events, cont’d Probability of Two Compound Events in a Single Trial P [toss an even number and one" xmpDM:startTime="312000" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="no." xmpDM:startTime="312000" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="divisible by 3]" xmpDM:startTime="312000" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Only valid with verbal explanations Prof." xmpDM:startTime="370133" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Dr.-Ing." xmpDM:startTime="370133" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Volker Lohweg 3.1" xmpDM:startTime="370133" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Probability Theory – A priori Probability (Statistically) Independent Events Across Trials Do not affect one another (are “mutually independent (exclusive)”)." xmpDM:startTime="370133" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="The events / measurements are de-correlated." xmpDM:startTime="370133" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Example 3.1-2:" xmpDM:startTime="370133" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="“toss a dice – revisited” e.g.:" xmpDM:startTime="370133" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="P [toss an even number and then toss a no." xmpDM:startTime="370133" xmpDM:duration="1000"/></rdf:li><rdf:li><rdf:Description xmpDM:name="divisible by 3]" xmpDM:startTime="370133" xmpDM:duration="1000"/></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                  </rdf:Description>\
               </rdf:li>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="TableOfContents" xmpDM:frameRate="f1000" xmpDM:trackName="Table of Contents">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:name="Einführung" xmpDM:startTime="0" tscDM:image="IFU_probability_312_VID_Thumbnails.png" tscDM:imageindex="0" tscDM:imageoffset="0" tscDM:imagerect="0, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="3.1 Probability Theory – A priori Probability" xmpDM:startTime="6033" tscDM:image="IFU_probability_312_VID_Thumbnails.png" tscDM:imageindex="1" tscDM:imageoffset="0" tscDM:imagerect="75, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="3.1 Probability Theory – A priori Probability" xmpDM:startTime="169733" tscDM:image="IFU_probability_312_VID_Thumbnails.png" tscDM:imageindex="2" tscDM:imageoffset="0" tscDM:imagerect="150, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="3.1 Probability Theory – A priori Probability" xmpDM:startTime="312000" tscDM:image="IFU_probability_312_VID_Thumbnails.png" tscDM:imageindex="3" tscDM:imageoffset="0" tscDM:imagerect="225, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="3.1 Probability Theory – A priori Probability" xmpDM:startTime="370133" tscDM:image="IFU_probability_312_VID_Thumbnails.png" tscDM:imageindex="4" tscDM:imageoffset="0" tscDM:imagerect="300, 0, 75, 42"/></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                  </rdf:Description>\
               </rdf:li>\
            </rdf:Bag>\
         </xmpDM:Tracks>\
         <tscDM:controller>\
            <rdf:Description xmpDM:name="tscplayer">\
               <tscDM:parameters>\
                  <rdf:Bag>\
                     <rdf:li xmpDM:name="autohide" xmpDM:value="true"/><rdf:li xmpDM:name="autoplay" xmpDM:value="false"/><rdf:li xmpDM:name="loop" xmpDM:value="false"/><rdf:li xmpDM:name="searchable" xmpDM:value="true"/><rdf:li xmpDM:name="captionsenabled" xmpDM:value="false"/><rdf:li xmpDM:name="sidebarenabled" xmpDM:value="false"/><rdf:li xmpDM:name="unicodeenabled" xmpDM:value="false"/><rdf:li xmpDM:name="backgroundcolor" xmpDM:value="000000"/><rdf:li xmpDM:name="sidebarlocation" xmpDM:value="left"/><rdf:li xmpDM:name="endaction" xmpDM:value="stop"/><rdf:li xmpDM:name="endactionparam" xmpDM:value="true"/><rdf:li xmpDM:name="locale" xmpDM:value="de-DE"/></rdf:Bag>\
               </tscDM:parameters>\
               <tscDM:controllerText>\
                  <rdf:Bag>\
                  </rdf:Bag>\
               </tscDM:controllerText>\
            </rdf:Description>\
         </tscDM:controller>\
         <tscDM:contentList>\
            <rdf:Description>\
               <tscDM:files>\
                  <rdf:Seq>\
                     <rdf:li xmpDM:name="0" xmpDM:value="IFU_probability_312_VID.mp4"/><rdf:li xmpDM:name="1" xmpDM:value="IFU_probability_312_VID_First_Frame.png"/><rdf:li xmpDM:name="2" xmpDM:value="IFU_probability_312_VID_Thumbnails.png"/></rdf:Seq>\
               </tscDM:files>\
            </rdf:Description>\
         </tscDM:contentList>\
      </rdf:Description>\
   </rdf:RDF>\
</x:xmpmeta>';
