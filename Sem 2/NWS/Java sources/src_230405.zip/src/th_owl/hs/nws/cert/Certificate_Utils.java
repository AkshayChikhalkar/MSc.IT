/*
 * TH Ostwestfalen-Lippe
 * FB Elektrotechnik und Technische Informatik
 * NWS
 */
package th_owl.hs.nws.cert;

import java.io.*;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Base64;
import th_owl.hs.nws.util.Dump;

public class Certificate_Utils {

  public static void main(String[] args) throws Exception {
    // Path to the Base64 encoded file:
    String fileName = "th-owl-de.pem";
    byte[] derData = base64toRawData(fileName);
    System.out.println(Dump.dump(derData));
  }

  /**
   *
   */
  public static byte[] base64toRawData(String fileName)
   throws CertificateException, FileNotFoundException, IOException {
    FileInputStream​ fis = new FileInputStream​(fileName);
    String base64String = new String(fis.readAllBytes());
    base64String = base64String.replaceAll("-.*\\R", "");

    Base64.Decoder base64Decoder = Base64.getMimeDecoder();
    return base64Decoder.decode(base64String);
  }

  /**
   * @param cert_der An DER encoded X.509 certificate.
   * @return A Java object representing the certificate.
   * @throws CertificateException
   */
  public static X509Certificate getCertificate(byte[] cert_der)
   throws CertificateException {
    Base64.Encoder base64Encoder = Base64.getMimeEncoder();
    String mimeCert = base64Encoder.encodeToString(cert_der);
    mimeCert = "-----BEGIN CERTIFICATE-----\r\n" + mimeCert
     + "\r\n-----END CERTIFICATE-----\r\n";
//    System.out.println(mimeCert);

    CertificateFactory cf
     = CertificateFactory.getInstance("X.509");
    return (X509Certificate) cf.generateCertificate(
     new ByteArrayInputStream(mimeCert.getBytes()));
  }
}
