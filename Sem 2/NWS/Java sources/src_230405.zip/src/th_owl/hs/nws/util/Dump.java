/*
 * Stefan Heiss
 * TH Ostwestfalen-Lippe
 * FB Elektrotechnik und Technische Informatik
 * Source code for NWS labs
 */
package th_owl.hs.nws.util;

import java.math.BigInteger;
import java.util.Formatter;

public class Dump {

  public final static String NL
   = System.getProperty("line.separator", "\r\n");

  public static byte[] hexString2byteArray(
   String hexString) {
    // remove all whitespaces
    hexString = hexString.replaceAll("\\s", "");
    hexString = hexString.replaceAll(":", "");

    if ((hexString.length() & 0x01) != 0) {
      throw new IllegalHexDumpException(
       "Odd number of nibbles!");
    }
    int byteArrayLength = hexString.length() >> 1;
    byte[] ba = new byte[byteArrayLength];
    for (int i = 0; i < byteArrayLength; ++i) {
      try {
        ba[i]
         = (byte) Integer.parseInt(
          hexString.substring(2 * i, 2 * i + 2), 16);
      } catch (NumberFormatException nfe) {
        throw new IllegalHexDumpException(
         "Invalid characters "
         + hexString.substring(2 * i, 2 * i + 2)
         + " at position " + 2 * i
         + " (of streamlined string)!");
      }
    }
    return ba;
  }

  // ------------------------------------------------------
  public static String dumpString(int i) {
    String retString = Integer.toString(i, 16);
    if ((retString.length() & 0x01) != 0) {
      retString = "0" + retString;
    }

    return retString.toUpperCase();
  }

  public static String dumpString(byte b) {
    return dumpString(b & 0xff);
  }

  public static String dumpString(byte[] data) {
    return dumpString(data, 0, data.length);
  }

  public static String dumpString(
   byte[] data, int offset, int length) {
    return dumpString(data, "", offset, length);
  }

  public static String dumpString(
   byte[] data, String interBytesString,
   int offset, int length) {
    if (offset < 0 || length < 0) {
      throw new IllegalArgumentException(
       "Values for offset and parameters must be "
       + "non-negative!");
    }
    if (data == null) {
      if (offset > 0 || length > 0) {
        throw new IllegalArgumentException(
         "Specified range not available in data!");
      }
      return "";
    }
    if ((offset + length) > data.length) {
      throw new IllegalArgumentException(
       "Specified range not available in data!");
    }

    StringBuffer sb = new StringBuffer(length
     * (2 + interBytesString.length()));
    for (int i = offset; i < offset + length; ++i) {
      if (i != 0) {
        sb.append(interBytesString);
      }
      sb.append(dumpString(data[i]));
    }
    return new String(sb);
  }

  // ------------------------------------------------------
  public static String dump(BigInteger b) {
    byte[] data = b.toByteArray();
    int l = data.length;
    if (l > 1 && data[0] == 0) {
      System.arraycopy(data, 1, data, 0, --l);
    }
    return dump(data, l);
  }

  public static String dump(byte[] data) {
    return dump(data, data.length);
  }

  public static String dump(byte[] data, int length) {
    StringBuffer sb
     = new StringBuffer(78 * ((length + 15) >> 4));
    char[] txt = new char[16];

    int i = 0;
    for (; i < length;) {
      if ((i & 0x0f) == 0) {
        sb.append(alignRight(
         Integer.toHexString(i) + "   ", 9, '0'));
      }

      int temp = (0xff & data[i]);
      sb.append(dumpString(temp));
      sb.append(" ");

      if (temp < 0x20 || temp > 0x7e) /// ???
      {
        txt[i++ & 0x0f] = '.';
      } //      if( temp == 0x0a || temp == 0x09 || temp == 0x0d ) /// ???
      //        txt[i++ & 0x0f] = (char)0;
      else {
        txt[i++ & 0x0f] = (char) temp;
      }

      if ((i & 0x0f) == 0) {
        sb.append("   ");
        sb.append(txt, 0, 16);
        sb.append(NL);
      }
    }

    if (i == 0) // empty data
    {
      sb.append("000000   ");
    }

    if ((i = (i & 0x0f)) != 0) {
      sb.append(fillString(3 * (16 - i), ' ') + "   ");
      sb.append(txt, 0, i);
      sb.append(NL);
    }

    return new String(sb.toString().trim());
  }

  /**
   * @return If str.length() &lt; totalLength, a String of
   * length totalLength is returned. (The original String
   * extended by specified character from the left.)
   */
  public static String alignRight(
   String str, int totalLength, char fillChar) {
    if (totalLength <= str.length()) {
      return str;
    }
    return fillString(totalLength - str.length(), fillChar)
     + str;
  }

  /**
   * @return If str.length() &lt; totalLength, a String of
   * length totalLength is returned. (The original String
   * extended by space characters from the left.)
   */
  public static String alignRight(
   String str, int totalLength) {
    return alignRight(str, totalLength, ' ');
  }

  /**
   * @return A String of repLength many repetitions of
   * specified character.
   */
  public static String fillString(
   int spaceLength, char fillChar) {
    if (spaceLength < 0) {
      spaceLength = 0;
    }
    StringBuffer sb = new StringBuffer(spaceLength);
    for (int i = 0; i < spaceLength; ++i) {
      sb.append(fillChar);
    }
    return new String(sb);
  }

  // ------------------------------------------------------
  public static String dumpIntArray(int[] array) {
    int nosPerLine = 4;
    StringBuffer sb = new StringBuffer();
    Formatter formatter = new Formatter(sb);
    for (int i = 0; i < array.length; ++i) {
      if (i != 0 && i % nosPerLine == 0) {
        sb.append(NL);
      }
      formatter.format("  %08x", array[i]);
    }
    sb.append(NL);
    return new String(sb);
  }
}
