/*
 * Stefan Heiss
 * TH Ostwestfalen-Lippe
 * FB Elektrotechnik und Technische Informatik
 * Source code for NWS labs
 */
package th_owl.hs.nws;

import th_owl.hs.nws.util.Dump;

public class UseDumpDemo {

  public static void main(String[] args) {

    String dataString =
       "d131dd02c5e6eec4693d9a0698aff95c2fcab58712467eab4004583eb8fb7f89"
     + "55ad340609f4b30283e488832571415a085125e8f7cdc99fd91dbdf280373c5b"
     + "d8823e3156348f5bae6dacd436c919c6dd53e2b487da03fd02396306d248cda0"
     + "e99f33420f577ee8ce54b67080a80d1ec69821bcb6a8839396f9652b6ff72a70";

    byte[] data = Dump.hexString2byteArray(dataString);
    
    System.out.println(Dump.dump(data));
    
    System.out.println(Dump.dumpString("Hallo".getBytes()));
    
  }

}
