/*
 * Stefan Heiss
 * TH Ostwestfalen-Lippe
 * FB Elektrotechnik und Technische Informatik
 * Source code for NWS labs
 */
package th_owl.hs.nws.util;

public class IllegalHexDumpException
 extends IllegalArgumentException {

  public IllegalHexDumpException(String s) {
    super(s);
  }
}
