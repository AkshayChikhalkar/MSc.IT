/*
 * Stefan Heiss, TH Ostwestfalen-Lippe
 * FB Elektrotechnik und Technische Informatik
 *
 * Enabling debuging of TLS handling: -Djavax.net.debug=all
 */
package nws_minichat_tls;

import java.io.*;
import java.net.*;
import java.util.logging.*;
import java.security.KeyStore;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

public class MiniChatClient {

  Socket socket;
  BufferedWriter outWriter;
  private boolean running = true;
  MessageHandler messageHandler;

  String trustStoreFile = ".\\tls_pki\\client\\clientTrustStore.ks";
  String ksType = "PKCS12";
  char[] passphrase = "clientSecret".toCharArray();
  
  MiniChatClient( MessageHandler messageHandler, String host ) throws Exception {
    this.messageHandler = messageHandler;
    int indexSep = host.lastIndexOf(":");
    int port = 0;
    if( indexSep >= 0 ) {
      port = Integer.parseInt(host.substring(indexSep + 1));
      host = host.substring(0, indexSep);
    }
    System.out.println("Connecting to: ");
    System.out.println(host + ":" + port);
//    socket = new Socket(host, port);
    socket = getSSLSocket(host, port);

    final BufferedReader inReader
     = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    outWriter
     = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

    new Thread() {

      @Override
      public void run() {
        while( running ) {
          try {
            String message = inReader.readLine();
            messageHandler.handleMessage(message);
          } catch(Exception ex) {
            Logger.getLogger(
             Client.class.getName()).log(Level.SEVERE, null, ex);
            close();
          }
        }
      }
    }.start();
  }

  void close() {
    if( socket != null ) {
      try {
        socket.close();
      } catch(IOException ex) {
        Logger.getLogger(
         MiniChatClient.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    running = false;
  }

  synchronized void send( String message ) {
    try {
      outWriter.write(message);
      outWriter.newLine();
      outWriter.flush();
    } catch(IOException ex) {
      Logger.getLogger(
       MiniChatClient.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  boolean isRunning() {
    return running;
  }

  private SSLSocket getSSLSocket( String host, int port ) throws Exception {
    // Truststore
    KeyStore ts = KeyStore.getInstance(ksType);
    ts.load(new FileInputStream(trustStoreFile), passphrase);
    TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
    tmf.init(ts);
    TrustManager[] tm = tmf.getTrustManagers();

    KeyManager[] km = null;

    SSLContext ctx = SSLContext.getInstance("TLS");
    ctx.init(km, tm, null);

    SSLSocketFactory ssf = ctx.getSocketFactory();
    SSLSocket sslSocket = (SSLSocket) ssf.createSocket(host, port);
    return sslSocket;
  }
}
