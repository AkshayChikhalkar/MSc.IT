/*
 * Stefan Heiss, TH Ostwestfalen-Lippe
 * FB Elektrotechnik und Technische Informatik
 *
 */
package nws_minichat_tls;

public interface MessageHandler {

  void handleMessage( String message );
}
