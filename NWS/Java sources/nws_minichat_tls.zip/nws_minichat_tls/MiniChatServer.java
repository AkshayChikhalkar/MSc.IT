/*
 * Stefan Heiss, TH Ostwestfalen-Lippe
 * FB Elektrotechnik und Technische Informatik
 *
 * Enabling debuging of TLS handling: -Djavax.net.debug=all
 */
package nws_minichat_tls;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.*;
import java.security.KeyStore;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.TrustManager;

public class MiniChatServer {

  final static int DEFAULT_PORT = 4911;
  int port = DEFAULT_PORT;
  InetAddress local;
  ServerSocket serverSocket;
  LinkedList<Client> clients = new LinkedList<>();
  boolean running = true;
  MessageHandler messageHandler;

  String keyStoreFile = ".\\tls_pki\\server\\serverKeyStore.ks";
  String ksType = "PKCS12";
  char[] passphrase = "serverSecret".toCharArray();

  MiniChatServer(MessageHandler messageHandler, String ipPortString)
   throws Exception {
    this.messageHandler = messageHandler;

    int indexSep = ipPortString.lastIndexOf(":");
    try {
      port = Integer.parseInt(ipPortString.substring(indexSep + 1));
    } catch( NumberFormatException ex ) {
    }

    try {
      if( indexSep == -1 ) {
        indexSep = ipPortString.length();
      }
      local = InetAddress.getByName(ipPortString.substring(0, indexSep));
    } catch( Exception ex ) {
      local = InetAddress.getLocalHost();
    }

    System.out.println("Opening Server Port: ");
    System.out.println(local + ":" + port);
//    serverSocket = new ServerSocket(port, 0, local);
    serverSocket = getSSLServerSocket(port, local);

    final MiniChatServer server = this;

    new Thread() {

      @Override
      public void run() {
        while( running ) {
          try {
            Socket socket = serverSocket.accept();
            Client client = new Client(server, socket);
            clients.add(client);
          } catch( IOException ex ) {
            Logger.getLogger(MiniChatServer.class.getName()).log(Level.SEVERE, null, ex);
          }
        }
      }
    }.start();
  }

  String getURL() {
    if( serverSocket != null ) {
      return serverSocket.getInetAddress().getHostAddress() + ":"
       + serverSocket.getLocalPort();
    }
    return "";
  }

  void close() {
    if( serverSocket != null ) {
      try {
        serverSocket.close();
      } catch( IOException ex ) {
        Logger.getLogger(
         MiniChatServer.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    running = false;
  }

  synchronized void send(String message) {
    for( Client client : clients ) {
      try {
        client.outWriter.write(message);
        client.outWriter.newLine();
        client.outWriter.flush();
      } catch( IOException ex ) {
        Logger.getLogger(
         MiniChatServer.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    messageHandler.handleMessage(message);
  }

  private ServerSocket getSSLServerSocket(int port, InetAddress local) throws Exception {
    KeyStore ks = KeyStore.getInstance(ksType);
    ks.load(new FileInputStream(keyStoreFile), passphrase);

    KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
    kmf.init(ks, passphrase);
    KeyManager[] km = kmf.getKeyManagers();

    TrustManager[] tm = null;

    SSLContext ctx = SSLContext.getInstance("TLS");
    ctx.init(km, tm, null);

    SSLServerSocketFactory ssf = ctx.getServerSocketFactory();
    SSLServerSocket sslSocket
     = (SSLServerSocket) ssf.createServerSocket(port, 0, local);
    return sslSocket;
  }
}

class Client {

  MiniChatServer server;
  BufferedReader inReader;
  BufferedWriter outWriter;

  Client(final MiniChatServer server, Socket socket) {
    this.server = server;
    try {
      inReader
       = new BufferedReader(new InputStreamReader(socket.getInputStream()));
      outWriter
       = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
      new Thread() {

        @Override
        public void run() {
          while( inReader != null ) {
            try {
              String message = inReader.readLine();
              server.send(message);
            } catch( IOException ex ) {
              Logger.getLogger(
               Client.class.getName()).log(Level.SEVERE, null, ex);
              close();
            }
          }
        }
      }.start();
    } catch( IOException ex ) {
      Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
      close();
    }
  }

  void close() {
    // Closing the returned InputStream will close the associated socket.
    // Closing this socket will also close the socket's InputStream and 
    // OutputStream.
    try {
      inReader.close();
    } catch( Exception e ) {
      e.printStackTrace();
    }
    inReader = null;
    server.clients.remove(this);
  }
}
