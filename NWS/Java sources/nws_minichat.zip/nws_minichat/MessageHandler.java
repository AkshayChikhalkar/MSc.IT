/*
 * Stefan Heiss, TH Ostwestfalen-Lippe
 * FB Elektrotechnik und Technische Informatik
 *
 */
package nws_minichat;

public interface MessageHandler {

  void handleMessage( String message );
}
