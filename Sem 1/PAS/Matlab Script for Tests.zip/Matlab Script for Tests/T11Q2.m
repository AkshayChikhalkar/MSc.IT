fprintf('%2f', norminv(1-0.005/2)^2/(4*0.015^2))
